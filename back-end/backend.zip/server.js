const http = require("http");
const express = require("express");
const app = express();
const cors = require('cors')
const sequelize = require("./config/db")
const bodyParser = require("body-parser");

app.use(express.json());
app.use(express.urlencoded({extended:false}));



/* models */
const User = require("./models/User");
const Product = require("./models/Product");
const News = require("./models/News");
const Tags = require("./models/Tags");

/* router */
const webApi = require("./routes/web.js");


app.use(cors());

app.use(async(req,res,next)=>{
    try{
        await sequelize.authenticate()
        console.log("connected")
        sequelize.sync()
    }catch(error){
        console.log(error)
    }
    next()
})

app.use('/admin',webApi.router);

app.get("/",(req,res,next)=>{

    return res.end("closed")
})

app.get("/users",(req,res)=>{
    res.send("users data")
})

app.listen("5000",()=>{
    console.log("5000 port connected")
})
