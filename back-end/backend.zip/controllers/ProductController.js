
const Product = require("../models/Product");
exports.store = (req,res,next) => {
    let {title, tagId, price} = req.body;
    let img = req.file.filename;
    let img_path = req.file.path;
    let product = Product.create({
        title,tagId,price,img,img_path
    });
    // console.log(product)
    
    if(product){
        // product.then((data)=>{
        //     console.log(data)
        //     return res.send({
        //         status: 200,
        //         data: product,
        //         message: 'success'
        //     });
        // });
         return res.send({
                status: 200,
                data: product,
                message: 'success'
            });
    }
    return res.send({
            status: 201,
            data: [],
            message: "failed"
        });
}

